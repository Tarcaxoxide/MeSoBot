class _BaseCommand:
    __slots__ = ()
